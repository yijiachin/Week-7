/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week7;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Random;
import java.lang.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import static week7.Task.hai;
/**
 *
 * @author 14057061
 */
public class Week5 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[][] arr=new double[200][100];
        double random=0;
        long start=0; 
        long end=0;
        double[] total = new double[200];
        ExecutorService exec = Executors.newFixedThreadPool(5);
        List<Future<Double>> futures = new ArrayList<Future<Double>>();
        for(int c=0;c<200;c++){
            for(int x=0;x<100;x++){
                random = ThreadLocalRandom.current().nextDouble(-5.12, 5.12);
                arr[c][x]=random;
            }
        }
        Task[] a=new Task[200];
        start = System.currentTimeMillis();
        for(int z=0;z<200;z++){
            a[z]=new Task(arr,z);
            futures.add(exec.submit(a[z]));
            try {
            total[z]=futures.get(z).get();
            }
            catch (Exception e1) {
                e1.printStackTrace();
            }
            
            System.out.printf("Thread number %d, Minimum is %f\n",z, total[z]);
        }
              
        exec.shutdown();
        try {
              exec.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } 
        catch (InterruptedException e) {}

        end = System.currentTimeMillis();
        System.out.printf("The minimum value found is %f\n\n", Task.hai);
        System.out.printf("The time is %d\n", end-start);
    }
    
}
