
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;


public class Task1 implements Runnable{
	Random rand = new Random();
	ArrayBlockingQueue list;
	int y=0;
	
	public Task1(ArrayBlockingQueue l)
	{
		list = l;
	}
	
	public void run()
	{
		while(true)
		{
                    y=rand.nextInt(100)+1;
                    try{
                    list.put(y);
                    }
                    catch(InterruptedException e){}
                    System.out.printf("New number is added : %d\n", y);
                    try{Thread.sleep(1000);}
                    catch(InterruptedException e){}
		}
	}
}
