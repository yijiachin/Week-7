
import java.util.concurrent.ArrayBlockingQueue;


public class Task2 implements Runnable{
	
	ArrayBlockingQueue list;
	int point;
	static boolean empty=false;

	public Task2(ArrayBlockingQueue l)
	{
		list = l;
	}
	
	public void run()
	{
		while(true)
		{

                    try{
                    System.out.printf("Number dropped: %d\n", list.take());
                    }
                    catch(InterruptedException e){}
                    synchronized(list){
                    list.notifyAll();}
                    try{Thread.sleep(1200);}
                    catch(InterruptedException e){}
		}
	}	
}
