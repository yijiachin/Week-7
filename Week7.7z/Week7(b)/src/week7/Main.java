
import java.util.concurrent.ArrayBlockingQueue;


public class Main {
	
	public static void main(String[] args)
	{
	ArrayBlockingQueue list= new ArrayBlockingQueue(5);
	
	Task1 p1 = new Task1(list);
	Task2 p2 = new Task2(list);
	
	Thread t1 = new Thread(p1);
	Thread t2 = new Thread(p2);
	
	t1.start();
	t2.start();
	}
}
